#![forbid(unsafe_code)]

use leptos::*;
use leptos_meta::*;
use serde::{Deserialize, Serialize};

// =====================
// Shared API types
// =====================

#[derive(Debug, Clone, Deserialize)]
pub struct AiRequest {
    pub prompt: String,
    pub system_instruction: Option<String>,
    pub asset: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AiResponse {
    pub text: String,
}

// =====================
// Server Function (Leptos) - Gemini API
// =====================

#[server(AiAnalyze, "/api")]
pub async fn ai_analyze(
    prompt: String,
    asset: String,
    indicators: String,
) -> Result<String, ServerFnError> {
    use std::env;

    let api_key = env::var("GEMINI_API_KEY")
        .unwrap_or_else(|_| "demo_key".to_string());

    if api_key == "demo_key" {
        return Ok(format!(
            "🤖 Fenrir AI Analysis for {}\n\nIndicators: {}\n\n• Please add GEMINI_API_KEY to .env file for real AI analysis\n• Get free API key from: https://aistudio.google.com/app/apikey\n\nCurrent analysis for {} based on {}:\n\n• Price action showing momentum\n• Key support levels holding\n• Wait for confirmation before entry\n\nDYOR!",
            asset, indicators, asset, indicators
        ));
    }

    let system = format!(
        "You are Fenrir AI, a Senior Technical Analyst specializing in cryptocurrency markets. \
        Current asset: {}. \
        Indicators on screen: {}. \
        Provide a concise, direct technical analysis. \
        Use bullet points. \
        Be specific about support/resistance levels. \
        End with DYOR. \
        Keep response under 150 words for voice synthesis.",
        asset, indicators
    );

    #[derive(Serialize)]
    struct GeminiReq {
        contents: Vec<Content>,
        generation_config: GenerationConfig,
    }

    #[derive(Serialize)]
    struct Content {
        parts: Vec<Part>,
    }

    #[derive(Serialize)]
    struct Part {
        text: String,
    }

    #[derive(Serialize)]
    struct GenerationConfig {
        temperature: f32,
        max_output_tokens: i32,
    }

    let body = GeminiReq {
        contents: vec![
            Content {
                parts: vec![Part {
                    text: format!("{}\n\nUser: {}", system, prompt.trim()),
                }],
            }
        ],
        generation_config: GenerationConfig {
            temperature: 0.4,
            max_output_tokens: 500,
        },
    };

    let url = format!(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={}",
        api_key
    );

    let client = reqwest::Client::new();
    let resp = client
        .post(&url)
        .header("Content-Type", "application/json")
        .json(&body)
        .send()
        .await
        .map_err(|e| ServerFnError::new(format!("network error: {e}")))?;

    if !resp.status().is_success() {
        let status = resp.status();
        let err = resp.text().await.unwrap_or_default();
        return Err(ServerFnError::new(format!(
            "provider error: {status} {err}"
        )));
    }

    #[derive(Deserialize)]
    struct GeminiResp {
        candidates: Vec<Candidate>,
    }

    #[derive(Deserialize)]
    struct Candidate {
        content: CandidateContent,
    }

    #[derive(Deserialize)]
    struct CandidateContent {
        parts: Vec<CandidatePart>,
    }

    #[derive(Deserialize)]
    struct CandidatePart {
        text: String,
    }

    let parsed = resp
        .json::<GeminiResp>()
        .await
        .map_err(|e| ServerFnError::new(format!("decode error: {e}")))?;

    Ok(parsed
        .candidates
        .get(0)
        .and_then(|c| c.content.parts.get(0))
        .map(|p| p.text.clone())
        .unwrap_or_else(|| "No response from AI. DYOR.".to_string()))
}

// =====================
// Leptos UI (Rust)
// =====================

#[component]
fn App() -> impl IntoView {
    provide_meta_context();

    view! {
        <Title text="Crypto Vibe Trade"/>
        <Meta name="viewport" content="width=device-width, initial-scale=1"/>
        <Meta charset="UTF-8"/>

        <Style id="cvt-css">{r#"
            :root {
                --neon-red: #ff3333;
                --neon-orange: #ff6b35;
                --neon-gray: #4a4a4a;
                --bg-black: #000000;
                --bg-dark: #0a0a0a;
                --border-dim: #1a1a1a;
                --text-primary: #ffffff;
                --text-secondary: #888888;
            }

            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                margin: 0;
                font-family: 'SF Mono', 'Fira Code', 'JetBrains Mono', monospace;
                background: var(--bg-black);
                color: var(--text-primary);
                overflow-x: hidden;
            }

            .container {
                max-width: 1400px;
                margin: 0 auto;
                padding: 0 32px;
            }

            /* Navbar */
            .nav {
                position: sticky;
                top: 0;
                background: rgba(0, 0, 0, 0.95);
                backdrop-filter: blur(20px);
                border-bottom: 1px solid var(--border-dim);
                z-index: 1000;
                animation: slideDown 0.6s ease-out;
            }

            @keyframes slideDown {
                from {
                    transform: translateY(-100%);
                    opacity: 0;
                }
                to {
                    transform: translateY(0);
                    opacity: 1;
                }
            }

            .bar {
                font-size: 9px;
                color: var(--text-secondary);
                padding: 8px 0;
                border-bottom: 1px solid var(--border-dim);
                letter-spacing: 0.3em;
                text-transform: uppercase;
            }

            .brand {
                display: flex;
                gap: 16px;
                align-items: center;
                padding: 16px 0;
            }

            .logo {
                width: 44px;
                height: 44px;
                border-radius: 12px;
                background: linear-gradient(135deg, var(--neon-red), var(--neon-orange));
                display: grid;
                place-items: center;
                color: #000;
                font-weight: 900;
                font-size: 14px;
                box-shadow: 0 0 20px rgba(255, 51, 51, 0.3);
                animation: pulse 3s ease-in-out infinite;
            }

            @keyframes pulse {
                0%, 100% { box-shadow: 0 0 20px rgba(255, 51, 51, 0.3); }
                50% { box-shadow: 0 0 30px rgba(255, 107, 53, 0.5); }
            }

            .brand-text {
                font-weight: 800;
                font-size: 18px;
                letter-spacing: -0.02em;
                background: linear-gradient(135deg, var(--text-primary), var(--neon-orange));
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }

            .brand-sub {
                font-size: 9px;
                letter-spacing: 0.35em;
                text-transform: uppercase;
                color: var(--text-secondary);
                margin-top: 2px;
            }

            /* Auth Buttons */
            .auth-buttons {
                display: flex;
                gap: 12px;
                align-items: center;
                margin-left: auto;
            }

            /* Hero */
            .hero {
                padding: 80px 0 60px;
                animation: fadeIn 1s ease-out;
            }

            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }

            h1 {
                font-size: 72px;
                letter-spacing: -0.05em;
                margin: 0 0 24px;
                font-weight: 800;
                background: linear-gradient(135deg, #fff, #888);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }

            .sub {
                color: var(--text-secondary);
                max-width: 700px;
                line-height: 1.7;
                font-size: 16px;
            }

            /* Grid */
            .grid {
                display: grid;
                gap: 20px;
                margin-top: 40px;
            }

            @media (min-width: 900px) {
                .grid-3 { grid-template-columns: repeat(3, 1fr); }
            }

            /* Asset Cards */
            .asset-card {
                border: 1px solid var(--border-dim);
                background: linear-gradient(135deg, rgba(20, 20, 20, 0.8), rgba(10, 10, 10, 0.9));
                border-radius: 16px;
                padding: 24px;
                cursor: pointer;
                transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
                position: relative;
                overflow: hidden;
            }

            .asset-card::before {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255, 107, 53, 0.1), transparent);
                transition: left 0.6s;
            }

            .asset-card:hover::before {
                left: 100%;
            }

            .asset-card:hover {
                border-color: var(--neon-orange);
                transform: translateY(-4px);
                box-shadow: 0 8px 32px rgba(255, 107, 53, 0.2);
            }

            .asset-card.active {
                border: 1px solid var(--neon-red);
                background: linear-gradient(135deg, rgba(255, 51, 51, 0.1), rgba(0, 0, 0, 0.9));
                box-shadow: 0 0 40px rgba(255, 51, 51, 0.3);
                transform: scale(1.02);
            }

            .asset-code {
                font-size: 11px;
                padding: 8px 12px;
                border-radius: 8px;
                border: 1px solid var(--border-dim);
                color: var(--text-primary);
                font-weight: 700;
                background: rgba(0, 0, 0, 0.5);
                transition: all 0.3s;
            }

            .asset-card:hover .asset-code {
                border-color: var(--neon-orange);
                color: var(--neon-orange);
            }

            .asset-card.active .asset-code {
                border-color: var(--neon-red);
                color: var(--neon-red);
                box-shadow: 0 0 10px rgba(255, 51, 51, 0.3);
            }

            /* Buttons */
            .btn {
                border: 1px solid var(--neon-gray);
                background: transparent;
                color: var(--text-primary);
                padding: 12px 20px;
                border-radius: 10px;
                cursor: pointer;
                font-family: inherit;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: 0.15em;
                text-transform: uppercase;
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                position: relative;
                overflow: hidden;
            }

            .btn::before {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                width: 0;
                height: 0;
                border-radius: 50%;
                background: rgba(255, 107, 53, 0.2);
                transform: translate(-50%, -50%);
                transition: width 0.6s, height 0.6s;
            }

            .btn:hover::before {
                width: 300px;
                height: 300px;
            }

            .btn:hover {
                border-color: var(--neon-orange);
                color: var(--neon-orange);
                box-shadow: 0 0 20px rgba(255, 107, 53, 0.4);
                transform: translateY(-2px);
            }

            .btn:active {
                transform: translateY(0);
            }

            .btn-primary {
                background: linear-gradient(135deg, var(--neon-red), var(--neon-orange));
                border: none;
                color: #000;
            }

            .btn-primary:hover {
                box-shadow: 0 0 30px rgba(255, 51, 51, 0.5);
                color: #000;
            }

            .btn-wallet {
                background: linear-gradient(135deg, #9945FF, #14F195);
                border: none;
                color: #000;
            }

            .btn-wallet:hover {
                box-shadow: 0 0 30px rgba(20, 241, 149, 0.4);
                color: #000;
            }

            .btn-analyzing {
                animation: analyzing 1s ease-in-out infinite;
                pointer-events: none;
                opacity: 0.7;
            }

            @keyframes analyzing {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(0.98); }
            }

            .btn-small {
                padding: 8px 16px;
                font-size: 10px;
            }

            /* Sections */
            .section {
                padding: 60px 0;
            }

            .section h2 {
                font-size: 32px;
                letter-spacing: -0.03em;
                margin: 0 0 12px;
                font-weight: 800;
            }

            .muted {
                color: var(--text-secondary);
                font-size: 11px;
                letter-spacing: 0.25em;
                text-transform: uppercase;
            }

            /* Panel */
            .panel {
                border: 1px solid var(--border-dim);
                border-radius: 16px;
                background: linear-gradient(135deg, rgba(20, 20, 20, 0.6), rgba(10, 10, 10, 0.8));
                backdrop-filter: blur(10px);
                overflow: hidden;
                margin-top: 24px;
            }

            .panel-head {
                padding: 16px 20px;
                border-bottom: 1px solid var(--border-dim);
                display: flex;
                justify-content: space-between;
                align-items: center;
                background: rgba(0, 0, 0, 0.5);
            }

            /* Chart Container */
            .chart-container {
                width: 100%;
                height: 600px;
                position: relative;
            }

            /* AI Terminal */
            .chat {
                display: grid;
                gap: 0;
            }

            @media (min-width: 900px) {
                .chat { grid-template-columns: 280px 1fr; }
            }

            .sidebar {
                border-right: 1px solid var(--border-dim);
                padding: 20px;
                background: rgba(0, 0, 0, 0.5);
            }

            .chatmain {
                min-height: 500px;
                display: flex;
                flex-direction: column;
            }

            .msgs {
                flex: 1;
                overflow: auto;
                padding: 20px;
                display: flex;
                flex-direction: column;
                gap: 16px;
                max-height: 400px;
            }

            .msg {
                max-width: 85%;
                padding: 16px 20px;
                border-radius: 16px;
                border: 1px solid var(--border-dim);
                background: rgba(20, 20, 20, 0.8);
                white-space: pre-wrap;
                line-height: 1.6;
                animation: messageIn 0.3s ease-out;
            }

            @keyframes messageIn {
                from {
                    opacity: 0;
                    transform: translateY(10px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .msg.user {
                align-self: flex-end;
                background: linear-gradient(135deg, rgba(255, 51, 51, 0.15), rgba(0, 0, 0, 0.9));
                border-color: rgba(255, 51, 51, 0.3);
            }

            .inputbar {
                padding: 20px;
                border-top: 1px solid var(--border-dim);
                display: flex;
                gap: 12px;
                background: rgba(0, 0, 0, 0.5);
            }

            input {
                flex: 1;
                padding: 14px 18px;
                border-radius: 12px;
                border: 1px solid var(--border-dim);
                background: rgba(0, 0, 0, 0.8);
                color: var(--text-primary);
                font-family: inherit;
                font-size: 13px;
                transition: all 0.3s;
            }

            input:focus {
                outline: none;
                border-color: var(--neon-orange);
                box-shadow: 0 0 20px rgba(255, 107, 53, 0.2);
            }

            input::placeholder {
                color: var(--text-secondary);
            }

            /* Footer */
            footer {
                border-top: 1px solid var(--border-dim);
                padding: 60px 0;
                color: var(--text-secondary);
                text-align: center;
                margin-top: 80px;
            }

            /* Animations */
            @keyframes glow {
                0%, 100% { opacity: 0.5; }
                50% { opacity: 1; }
            }

            .indicator-badge {
                display: inline-block;
                padding: 4px 8px;
                margin: 4px;
                border: 1px solid var(--neon-gray);
                border-radius: 6px;
                font-size: 10px;
                letter-spacing: 0.15em;
                color: var(--text-secondary);
                transition: all 0.3s;
            }

            .indicator-badge:hover {
                border-color: var(--neon-orange);
                color: var(--neon-orange);
                box-shadow: 0 0 10px rgba(255, 107, 53, 0.3);
            }

            .indicator-badge.active {
                border-color: var(--neon-red);
                color: var(--neon-red);
                background: rgba(255, 51, 51, 0.1);
            }
        "#}</Style>

        <div class="nav">
            <div class="bar">
                <div class="container">"Powered by Gemini AI • Protected by Fenrir • Terminal V.10.0"</div>
            </div>
            <div class="container brand">
                <div class="logo">"CVT"</div>
                <div>
                    <div class="brand-text">"Crypto Vibe Trade"</div>
                    <div class="brand-sub">"Advanced Trading Terminal"</div>
                </div>
                <div class="auth-buttons">
                    <button class="btn btn-small">"Login"</button>
                    <button class="btn btn-small btn-primary">"Register"</button>
                </div>
            </div>
        </div>

        <main class="container">
            <Hero/>
            <ChartSection/>
            <AiTerminal/>
        </main>

        <footer>
            <div class="container">
                <div style="font-weight: 900; letter-spacing: 0.25em; margin-bottom: 12px;">"NOT FINANCIAL ADVICE"</div>
                <div style="font-size: 12px;">"DYOR — Do Your Own Research"</div>
            </div>
        </footer>
    }
}

#[component]
fn Hero() -> impl IntoView {
    let (asset, set_asset) = create_signal("BTC".to_string());

    let mk_card = move |code: &'static str, title: &'static str, subtitle: &'static str| {
        let code_a = code.to_string();

        let class_name = move || {
            if asset.get() == code_a {
                "asset-card active".to_string()
            } else {
                "asset-card".to_string()
            }
        };

        view! {
            <div class=class_name on:click=move |_| set_asset.set(code.to_string())>
                <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:16px;">
                    <div>
                        <div style="font-weight:800; font-size:20px; margin-bottom:4px;">{title}</div>
                        <div class="muted">{subtitle}</div>
                    </div>
                    <div class="asset-code">{code}</div>
                </div>
                <div style="margin-top:20px; font-size:28px; font-weight:800; letter-spacing:-0.02em;">
                    {format!("${}", if code == "BTC" { "97,432.50" } else if code == "SOL" { "124.87" } else { "32.15" })}
                </div>
                <div class="muted" style="margin-top:8px; font-size:11px;">
                    {format!("{}2.4% (24h)", if code == "BTC" { "+" } else { "-" })}
                </div>
            </div>
        }
    };

    view! {
        <section class="hero">
            <h1>"Trading Evolved."</h1>
            <p class="sub">
                "Advanced technical analysis with AI-powered insights. "
                "Real-time charts, predictive indicators, and voice analysis for serious traders."
            </p>

            <div class="grid grid-3">
                {mk_card("BTC", "Bitcoin", "Digital Gold")}
                {mk_card("SOL", "Solana", "High-Speed Chain")}
                {mk_card("ZEC", "ZCash", "Privacy Coin")}
            </div>

            <div style="display:flex; gap:16px; margin-top:40px; justify-content:center; flex-wrap:wrap;">
                <button class="btn btn-primary" style="padding:16px 32px; font-size:14px;">"Open App"</button>
                <button class="btn btn-wallet" style="padding:16px 32px; font-size:14px;">"Connect Wallet"</button>
            </div>
        </section>
    }
}

#[component]
fn ChartSection() -> impl IntoView {
    let (asset, set_asset) = create_signal("BTC".to_string());
    let (chart_key, set_chart_key) = create_signal(0);

    // Get TradingView symbol based on asset
    let tv_symbol = move || {
        match asset.get().as_str() {
            "BTC" => "BINANCE:BTCUSDT.P",
            "SOL" => "BINANCE:SOLUSDT.P",
            "ZEC" => "BINANCE:ZECUSDT.P",
            _ => "BINANCE:BTCUSDT.P",
        }
    };

    let change_chart = move |new_asset: String| {
        set_asset.set(new_asset.clone());
        set_chart_key.update(|k| *k += 1);
    };

    view! {
        <section class="section" id="chart">
            <div style="display:flex; justify-content:space-between; align-items:center; gap:16px; flex-wrap:wrap;">
                <div>
                    <h2>"Live Market Data"</h2>
                    <div class="muted">"Real-time price action and volume"</div>
                </div>
                <div style="display:flex; gap:12px;">
                    <button
                        class="btn"
                        class:btn-primary=move || asset.get() == "BTC"
                        on:click=move |_| change_chart("BTC".to_string())
                    >"BTC"</button>
                    <button
                        class="btn"
                        class:btn-primary=move || asset.get() == "SOL"
                        on:click=move |_| change_chart("SOL".to_string())
                    >"SOL"</button>
                    <button
                        class="btn"
                        class:btn-primary=move || asset.get() == "ZEC"
                        on:click=move |_| change_chart("ZEC".to_string())
                    >"ZEC"</button>
                </div>
            </div>

            <div class="panel" style="margin-top:24px;">
                <div class="panel-head">
                    <div style="display:flex; align-items:center; gap:12px;">
                        <span class="muted" style="color:#fff; font-size:14px;">{move || asset.get()}</span>
                        <span class="indicator-badge">"Ichimoku"</span>
                        <span class="indicator-badge">"RSI"</span>
                        <span class="indicator-badge">"MACD"</span>
                        <span class="indicator-badge">"BB"</span>
                    </div>
                    <div class="muted">"1D INTERVAL"</div>
                </div>
                <div class="chart-container">
                    <iframe
                        key=move || chart_key.get()
                        style="width:100%; height:100%; border:none;"
                        src=move || format!(
                            "https://s.tradingview.com/widgetembed/?frameElementId=tradingview_{}&symbol={}&interval=D&hidesidetoolbar=1&symboledit=1&saveimage=1&toolbarbg=f1f3f6&studies=%5B%5D&theme=dark&style=1&timezone=Etc%2FUTC",
                            chart_key.get(),
                            tv_symbol()
                        )
                    ></iframe>
                </div>
            </div>
        </section>
    }
}

#[component]
fn AiTerminal() -> impl IntoView {
    use std::rc::Rc;

    let (asset, set_asset) = create_signal("BTC".to_string());
    let (indicators, set_indicators) = create_signal("Ichimoku Cloud, RSI, MACD".to_string());
    let (input, set_input) = create_signal(String::new());
    let (messages, set_messages) = create_signal::<Vec<(bool, String)>>(vec![(
        false,
        "Fenrir AI initialized. Select indicators above and click Analyze for voice analysis.".to_string(),
    )]);
    let (is_analyzing, set_is_analyzing) = create_signal(false);

    let analyze = create_action(move |_: &()| {
        let asset = asset.get();
        let indicators = indicators.get();
        set_is_analyzing.set(true);
        async move {
            let result = ai_analyze(
                "Provide technical analysis based on current indicators and market conditions.".to_string(),
                asset,
                indicators,
            ).await;
            set_is_analyzing.set(false);
            result
        }
    });

    create_effect(move |_| {
        if let Some(result) = analyze.value().get() {
            match result {
                Ok(text) => {
                    let text_clone = text.clone();
                    set_messages.update(|m| m.push((false, text)));
                    // Auto-speak the response using JavaScript
                    let _ = leptos::spawn_local(async move {
                        if let Some(window) = web_sys::window() {
                            if let Ok(speech) = window.speech_synthesis() {
                                if let Ok(utterance) = web_sys::SpeechSynthesisUtterance::new() {
                                    utterance.set_text(&text_clone);
                                    utterance.set_rate(0.9);
                                    utterance.set_pitch(1.0);
                                    let _ = speech.speak(&utterance);
                                }
                            }
                        }
                    });
                }
                Err(e) => {
                    set_messages.update(|m| m.push((false, format!("Error: {}", e))))
                }
            }
        }
    });

    let do_submit: Rc<dyn Fn()> = Rc::new(move || {
        let q = input.get().trim().to_string();
        if q.is_empty() {
            return;
        }
        set_input.set(String::new());
        set_messages.update(|m| m.push((true, q.clone())));
        // Trigger analysis
        analyze.dispatch(());
    });

    let submit_click = {
        let do_submit = do_submit.clone();
        move |_| (do_submit)()
    };

    let submit_enter = {
        let do_submit = do_submit.clone();
        move |ev: leptos::ev::KeyboardEvent| {
            if ev.key() == "Enter" {
                (do_submit)();
            }
        }
    };

    view! {
        <section class="section" id="ai-analyst">
            <div>
                <h2>"AI Analyst"</h2>
                <div class="muted">"Gemini-powered technical analysis with voice output"</div>
            </div>

            <div class="panel" style="margin-top:24px;">
                <div class="chat">
                    <div class="sidebar">
                        <div class="muted" style="margin-bottom:16px;">"Asset"</div>
                        <div style="display:flex; flex-direction:column; gap:12px;">
                            <button
                                class="btn"
                                class:btn-primary=move || asset.get() == "BTC"
                                on:click=move |_| set_asset.set("BTC".to_string())
                            >"Bitcoin"</button>
                            <button
                                class="btn"
                                class:btn-primary=move || asset.get() == "SOL"
                                on:click=move |_| set_asset.set("SOL".to_string())
                            >"Solana"</button>
                            <button
                                class="btn"
                                class:btn-primary=move || asset.get() == "ZEC"
                                on:click=move |_| set_asset.set("ZEC".to_string())
                            >"ZCash"</button>
                        </div>

                        <div class="muted" style="margin:24px 0 16px;">"Indicators"</div>
                        <div style="display:flex; flex-direction:column; gap:8px;">
                            <label style="display:flex; align-items:center; gap:8px; font-size:12px; cursor:pointer;">
                                <input
                                    type="checkbox"
                                    checked=true
                                    on:change=move |ev| {
                                        let mut current = indicators.get();
                                        if event_target_checked(&ev) {
                                            if !current.contains("Ichimoku") {
                                                current = format!("{}Ichimoku Cloud", if current.is_empty() { "" } else { ", " });
                                            }
                                        } else {
                                            current = current.replace("Ichimoku Cloud", "").trim().trim_end_matches(',').trim().trim_start_matches(',').to_string();
                                        }
                                        set_indicators.set(current);
                                    }
                                />
                                "Ichimoku Cloud"
                            </label>
                            <label style="display:flex; align-items:center; gap:8px; font-size:12px; cursor:pointer;">
                                <input
                                    type="checkbox"
                                    checked=true
                                    on:change=move |ev| {
                                        let mut current = indicators.get();
                                        if event_target_checked(&ev) {
                                            if !current.contains("RSI") {
                                                current = format!("{}RSI", if current.is_empty() { "" } else { ", " });
                                            }
                                        } else {
                                            current = current.replace("RSI", "").trim().trim_end_matches(',').trim().trim_start_matches(',').to_string();
                                        }
                                        set_indicators.set(current);
                                    }
                                />
                                "RSI"
                            </label>
                            <label style="display:flex; align-items:center; gap:8px; font-size:12px; cursor:pointer;">
                                <input
                                    type="checkbox"
                                    checked=true
                                    on:change=move |ev| {
                                        let mut current = indicators.get();
                                        if event_target_checked(&ev) {
                                            if !current.contains("MACD") {
                                                current = format!("{}MACD", if current.is_empty() { "" } else { ", " });
                                            }
                                        } else {
                                            current = current.replace("MACD", "").trim().trim_end_matches(',').trim().trim_start_matches(',').to_string();
                                        }
                                        set_indicators.set(current);
                                    }
                                />
                                "MACD"
                            </label>
                        </div>
                    </div>

                    <div class="chatmain">
                        <div class="msgs">
                            <For
                                each=move || messages.get()
                                key=|(_, s)| s.clone()
                                children=move |(is_user, text)| {
                                    view! {
                                        <div class=move || if is_user { "msg user" } else { "msg" }>
                                            {text}
                                        </div>
                                    }
                                }
                            />
                        </div>

                        <div class="inputbar">
                            <input
                                prop:value=move || input.get()
                                on:input=move |ev| set_input.set(event_target_value(&ev))
                                on:keydown=submit_enter
                                placeholder="Ask about technical indicators, patterns, or market conditions..."
                            />
                            <button
                                class="btn btn-primary"
                                class:btn-analyzing=is_analyzing
                                on:click=submit_click
                                disabled=is_analyzing
                            >
                                {move || if is_analyzing.get() { "Analyzing..." } else { "Analyze" }}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    }
}

// =====================
// Entrypoint (SSR server)
// =====================

#[tokio::main]
async fn main() {
    use axum::{
        http::StatusCode,
        response::IntoResponse,
        routing::post,
        Router,
    };
    use leptos_axum::{generate_route_list, LeptosRoutes};
    use std::net::SocketAddr;
    use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

    dotenvy::dotenv().ok();

    tracing_subscriber::registry()
        .with(tracing_subscriber::EnvFilter::from_default_env())
        .with(tracing_subscriber::fmt::layer())
        .init();

    let leptos_options = LeptosOptions::default();
    let routes = generate_route_list(App);

    let app = Router::new()
        .route("/api/*fn_name", post(leptos_axum::handle_server_fns))
        .leptos_routes(&leptos_options, routes, App)
        .fallback(|| async {
            (StatusCode::NOT_FOUND, "Not Found").into_response()
        })
        .with_state(leptos_options);

    let addr = std::env::var("CVT_ADDR")
        .ok()
        .and_then(|s| s.parse::<SocketAddr>().ok())
        .unwrap_or_else(|| SocketAddr::from(([127, 0, 0, 1], 3000)));

    tracing::info!("listening on http://{}", addr);
    let listener = tokio::net::TcpListener::bind(&addr).await.unwrap();
    axum::serve(listener, app)
        .await
        .expect("server failed");
}
